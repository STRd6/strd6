--
-- Definition of table `compositions`
--

DROP TABLE IF EXISTS `compositions`;
CREATE TABLE `compositions` (
  `id` int(11) NOT NULL auto_increment,
  `product_id` int(11) default NULL,
  `component_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `quantity` int(11) default '1',
  `line_num` int(11) default NULL,
  `fixed` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `compositions`
--

/*!40000 ALTER TABLE `compositions` DISABLE KEYS */;
INSERT INTO `compositions` (`id`,`product_id`,`component_id`,`created_at`,`updated_at`,`quantity`,`line_num`,`fixed`) VALUES 
 (1,1,2,NULL,NULL,1,NULL,NULL),
 (2,1,3,NULL,NULL,1,NULL,NULL),
 (3,NULL,190,'2008-07-24 10:27:34','2008-07-24 10:27:34',5,NULL,NULL),
 (4,NULL,216,'2008-07-24 10:29:04','2008-07-24 10:29:04',1,NULL,NULL),
 (5,NULL,217,'2008-07-24 10:29:04','2008-07-24 10:29:04',1,NULL,NULL),
 (6,NULL,216,'2008-07-24 10:39:22','2008-07-24 10:39:22',1,NULL,NULL),
 (7,NULL,217,'2008-07-24 10:39:22','2008-07-24 10:39:22',1,NULL,NULL),
 (8,218,216,'2008-07-24 10:48:30','2008-07-24 10:48:30',1,NULL,NULL),
 (9,218,217,'2008-07-24 10:48:30','2008-07-24 10:48:30',1,NULL,NULL),
 (10,193,219,'2008-07-24 12:04:26','2008-07-24 12:04:26',1,NULL,NULL),
 (11,193,220,'2008-07-24 12:04:26','2008-07-24 12:04:26',1,NULL,NULL),
 (12,193,221,'2008-07-24 12:04:26','2008-07-24 12:04:26',1,NULL,NULL),
 (13,193,222,'2008-07-24 12:04:26','2008-07-24 12:04:26',1,NULL,NULL),
 (14,216,190,'2008-07-28 10:23:58','2008-07-28 10:23:58',5,NULL,NULL),
 (15,216,217,'2008-07-28 10:23:58','2008-07-28 10:23:58',1,NULL,NULL),
 (16,NULL,190,'2008-07-28 13:48:27','2008-07-28 13:48:27',1,NULL,NULL),
 (17,NULL,217,'2008-07-28 13:48:27','2008-07-28 13:48:27',1,NULL,NULL),
 (18,NULL,190,'2008-07-28 13:49:52','2008-07-28 13:49:52',1,NULL,NULL),
 (19,NULL,217,'2008-07-28 13:49:52','2008-07-28 13:49:52',1,NULL,NULL),
 (20,NULL,190,'2008-07-28 13:52:42','2008-07-28 13:52:42',1,NULL,NULL),
 (21,NULL,217,'2008-07-28 13:52:43','2008-07-28 13:52:43',1,NULL,NULL),
 (22,224,190,'2008-07-28 14:49:57','2008-07-28 14:49:57',1,NULL,NULL),
 (23,224,217,'2008-07-28 14:49:57','2008-07-28 14:49:57',1,NULL,NULL);
/*!40000 ALTER TABLE `compositions` ENABLE KEYS */;